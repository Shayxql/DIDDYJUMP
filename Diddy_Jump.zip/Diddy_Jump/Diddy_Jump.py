import pygame
import random
import os

pygame.init()
screen_width, screen_height = 400, 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Doodle Jump - Procédural")

# Chargement du joueur (image) - VERSION ROBUSTE
player_image = None
script_dir = os.path.dirname(os.path.abspath(__file__))
image_path = os.path.join(script_dir, "player.png")

try:
    player_image = pygame.image.load(image_path).convert_alpha()
    player_image = pygame.transform.scale(player_image, (50, 50))
    print("✅ Image player.png chargée !")
except pygame.error:
    print("❌ Image player.png introuvable. Utilisation du cube vert.")
    print(f"   Cherché dans : {image_path}")
    player_image = None

# Joueur
player_x, player_y = screen_width // 2, screen_height // 2
player_w, player_h = 50, 50
player_vy = 0
gravity = 0.6
jump_power = -19

# Paramètres de difficulté
base_min_gap = 60
base_max_gap = 100
base_fragile_chance = 0.3

# MOON WORLD
MOON_SCORE = 200
moon_world_active = False

# Couleurs
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
SKY = (135, 206, 250)
SKY_MOON = (20, 20, 40)
MOON_YELLOW = (255, 255, 100)
RED = (255, 0, 0)
YELLOW = (255, 255, 0)
BLUE = (0, 0, 255)
GRAY_MOON = (120, 120, 120)

# POWERUPS
powerups = []
active_jetpack_time = 0
has_shield = False
JETPACK_DURATION = 60

# NUAGES
cloud_patterns = [
    ["..12221..", ".1222221.", "112333211", ".1333331.", "..13331.."],
    ["...1221..", "..122221.", ".11222211", ".12333321", "..13331.."],
    ["..12221..", ".12222211", "122333321", ".12333321", "...1331.."],
    ["...122..", "..12221.", ".1222221", "11233321", ".13331.."],
]

clouds = []
MAX_CLOUDS = 8


def init_clouds():
    global clouds
    clouds = []
    for i in range(MAX_CLOUDS):
        x = random.randint(-30, screen_width - 30)
        y = random.randint(-screen_height, screen_height)
        scale = random.uniform(1.8, 2.6)
        pattern_index = random.randint(0, len(cloud_patterns) - 1)
        speed = random.uniform(0.3, 0.8)
        clouds.append([x, y, scale, pattern_index, speed])


def update_clouds():
    for c in clouds:
        c[1] += c[4]
        if c[1] > screen_height + 40:
            c[0] = random.randint(-30, screen_width - 30)
            c[1] = random.randint(-screen_height, -40)
            c[2] = random.uniform(1.8, 2.6)
            c[3] = random.randint(0, len(cloud_patterns) - 1)
            c[4] = random.uniform(0.3, 0.8)


def draw_cloud(surface, x, y, scale, pattern):
    block = int(4 * scale)
    light = (245, 245, 255)
    mid = (220, 220, 235)
    dark = (180, 180, 200)
    outline = (100, 100, 120)

    rows = len(pattern)
    cols = len(pattern[0])

    for j in range(rows):
        for i in range(cols):
            if pattern[j][i] == ".":
                continue
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    nj = j + dy
                    ni = i + dx
                    if 0 <= nj < rows and 0 <= ni < cols:
                        if pattern[nj][ni] == ".":
                            rx = x + i * block
                            ry = y + j * block
                            rect = pygame.Rect(rx, ry, block, block)
                            pygame.draw.rect(surface, outline, rect)

    for j in range(rows):
        for i in range(cols):
            c = pattern[j][i]
            if c == ".":
                continue
            if c == "1":
                color = mid
            elif c == "2":
                color = light
            elif c == "3":
                color = dark
            else:
                color = mid
            rx = x + i * block
            ry = y + j * block
            rect = pygame.Rect(rx, ry, block, block)
            pygame.draw.rect(surface, color, rect)


def draw_background():
    global moon_world_active
    if moon_world_active:
        screen.fill(SKY_MOON)
        for _ in range(20):
            x = random.randint(0, screen_width)
            y = random.randint(0, screen_height // 2)
            pygame.draw.circle(screen, WHITE, (x, y), 1)
    else:
        screen.fill(SKY)

    if not moon_world_active:
        for x, y, scale, pat_idx, _speed in clouds:
            draw_cloud(screen, x, y, scale, cloud_patterns[pat_idx])


def get_difficulty_params(score):
    fragile_chance = base_fragile_chance + min(score / 50.0, 0.5)
    fragile_chance = min(fragile_chance, 0.8)
    difficulty_factor = min(score / 50.0, 1.0)
    min_gap = int(base_min_gap - 20 * difficulty_factor)
    max_gap = int(base_max_gap - 30 * difficulty_factor)
    min_gap = max(30, min_gap)
    max_gap = max(min_gap + 10, max_gap)
    return fragile_chance, min_gap, max_gap


def create_initial_platforms():
    platforms_local = []
    safety_platform_y = screen_height - 20
    platforms_local.append([0, safety_platform_y, screen_width, 20, "solid"])
    spawn_y = screen_height - 80
    fragile_chance, min_gap, max_gap = get_difficulty_params(0)
    for i in range(6):
        x = random.randint(0, screen_width - 60)
        y = spawn_y
        plat_type = "solid"
        if random.random() < fragile_chance:
            plat_type = "fragile"
        platforms_local.append([x, y, 60, 12, plat_type])
        spawn_y -= random.randint(min_gap, max_gap)
    return platforms_local


def draw_text(surface, text, size, x, y, color=BLACK, center=True):
    font = pygame.font.SysFont(None, size)
    txt = font.render(text, True, color)
    rect = txt.get_rect()
    if center:
        rect.center = (x, y)
    else:
        rect.topleft = (x, y)
    surface.blit(txt, rect)


def show_start_screen():
    waiting = True
    clock = pygame.time.Clock()
    frame = 0
    init_clouds()

    while waiting:
        clock.tick(60)
        frame += 1
        update_clouds()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                waiting = False
                pygame.quit()
                quit()
            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_SPACE, pygame.K_RETURN):
                    waiting = False

        draw_background()

        # TITRE GROS
        draw_text(screen, "DIDDY JUMP", 72, screen_width // 2, screen_height // 2 - 100)

        # SPRITE PERSO SOUS LE TITRE
        if player_image:
            player_rect_menu = pygame.Rect(screen_width // 2 - 25, screen_height // 2 - 40, 50, 50)
            screen.blit(player_image, player_rect_menu)
        else:
            pygame.draw.rect(screen, (0, 255, 0), (screen_width // 2 - 25, screen_height // 2 - 40, 50, 50))

        # Instructions
        draw_text(screen, "Fleches pour bouger", 40, screen_width // 2, screen_height // 2 + 40)
        draw_text(screen, "Le personnage saute tout seul", 24, screen_width // 2, screen_height // 2 + 80)

        if (frame // 30) % 2 == 0:
            draw_text(screen, "ESPACE ou ENTREE pour commencer", 24, screen_width // 2, screen_height * 3 // 4)

        pygame.display.flip()


def show_game_over_screen(score, highscore):
    global moon_world_active
    waiting = True
    clock = pygame.time.Clock()
    frame = 0
    moon_world_active = False
    while waiting:
        clock.tick(60)
        frame += 1
        update_clouds()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                waiting = False
                pygame.quit()
                quit()
            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_SPACE, pygame.K_RETURN):
                    waiting = False
        draw_background()
        draw_text(screen, "GAME OVER", 72, screen_width // 2, screen_height // 4)
        draw_text(screen, f"Score : {score}", 40, screen_width // 2, screen_height // 2 - 10)
        draw_text(screen, f"Highscore : {highscore}", 40, screen_width // 2, screen_height // 2 + 40)
        if (frame // 30) % 2 == 0:
            draw_text(screen, "ESPACE ou ENTREE pour rejouer", 24, screen_width // 2, screen_height * 3 // 4)
        pygame.display.flip()


def spawn_powerup_on_platform(plat):
    global powerups
    if plat[2] == screen_width:
        return
    if random.random() < 0.05:
        p_type = random.choice(["spring", "jetpack", "shield"])
        px = plat[0] + plat[2] // 2 - 10
        py = plat[1] - 20
        powerups.append([px, py, 20, 20, p_type])


def draw_powerups():
    for p in powerups:
        rect = pygame.Rect(p[0], p[1], p[2], p[3])
        if p[4] == "spring":
            color = RED
        elif p[4] == "jetpack":
            color = YELLOW
        else:
            color = BLUE
        pygame.draw.rect(screen, color, rect)


def update_powerups_scroll(dy):
    for p in powerups:
        p[1] += dy
    powerups[:] = [p for p in powerups if p[1] < screen_height]


def handle_powerup_collision(player_rect):
    global player_vy, active_jetpack_time, has_shield, powerups
    new_powerups = []
    for p in powerups:
        rect = pygame.Rect(p[0], p[1], p[2], p[3])
        if player_rect.colliderect(rect):
            if p[4] == "spring":
                player_vy = jump_power * 1.5
            elif p[4] == "jetpack":
                active_jetpack_time = JETPACK_DURATION
                player_vy = jump_power * 2
            elif p[4] == "shield":
                has_shield = True
        else:
            new_powerups.append(p)
    powerups = new_powerups


def game_loop(highscore):
    global player_x, player_y, player_vy, powerups, active_jetpack_time, has_shield, moon_world_active
    platforms = create_initial_platforms()
    powerups = []
    active_jetpack_time = 0
    has_shield = False
    moon_world_active = False

    for plat in platforms:
        spawn_powerup_on_platform(plat)

    score = 0
    running = True
    clock = pygame.time.Clock()
    player_x, player_y = screen_width // 2, screen_height // 2
    player_vy = 0

    init_clouds()

    while running:
        clock.tick(60)
        update_clouds()
        draw_background()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                quit()

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            player_x -= 5
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            player_x += 5

        if player_x < 0:
            player_x = 0
        if player_x > screen_width - player_w:
            player_x = screen_width - player_w

        if score > MOON_SCORE and not moon_world_active:
            moon_world_active = True
            print("🌙 MONDE LUNE ACTIVÉ ! 🌙")

        if active_jetpack_time > 0:
            active_jetpack_time -= 1
            player_vy += gravity * 0.1
        else:
            player_vy += gravity

        player_y += player_vy
        player_rect = pygame.Rect(player_x, player_y, player_w, player_h)

        new_platforms = []
        for plat in platforms:
            plat_rect = pygame.Rect(plat[0], plat[1], plat[2], plat[3])
            if player_vy > 0 and player_rect.colliderect(plat_rect):
                if player_rect.bottom <= plat_rect.bottom:
                    player_rect.bottom = plat_rect.top
                    player_y = player_rect.y
                    player_vy = jump_power
                    score += 1

                    if moon_world_active:
                        continue
                    elif plat[4] == "fragile":
                        continue
                    else:
                        spawn_powerup_on_platform(plat)
            new_platforms.append(plat)
        platforms = new_platforms

        handle_powerup_collision(player_rect)

        if player_y < screen_height // 3:
            dy = screen_height // 3 - player_y
            player_y = screen_height // 3
            player_rect.y = player_y
            for plat in platforms:
                plat[1] += dy
            platforms = [p for p in platforms if p[1] < screen_height]
            update_powerups_scroll(dy)

            if platforms:
                highest_y = min(p[1] for p in platforms)
            else:
                highest_y = screen_height

            fragile_chance, min_gap, max_gap = get_difficulty_params(score)
            while len(platforms) < 7:
                x = random.randint(0, screen_width - 60)
                y = highest_y - random.randint(min_gap, max_gap)
                plat_type = "solid"
                if not moon_world_active and random.random() < fragile_chance:
                    plat_type = "fragile"
                new_plat = [x, y, 60, 12, plat_type]
                platforms.append(new_plat)
                spawn_powerup_on_platform(new_plat)
                highest_y = y

        # DESSIN DU JOUEUR
        if player_image:
            screen.blit(player_image, player_rect)
        else:
            pygame.draw.rect(screen, (0, 255, 0), player_rect)

        for plat in platforms:
            if plat[2] == screen_width:
                color = GRAY_MOON if moon_world_active else (100, 100, 255)
            else:
                if moon_world_active:
                    color = MOON_YELLOW
                else:
                    color = (160, 82, 45) if plat[4] == "solid" else (200, 200, 200)
            pygame.draw.rect(screen, color, (plat[0], plat[1], plat[2], plat[3]))

        draw_powerups()

        font = pygame.font.SysFont(None, 28)
        text = font.render(f"Score : {score}", True, WHITE if moon_world_active else BLACK)
        screen.blit(text, (10, 10))

        world_text = "LUNE" if moon_world_active else "CIEL"
        world_surf = font.render(world_text, True, MOON_YELLOW if moon_world_active else BLACK)
        screen.blit(world_surf, (10, 35))

        if has_shield:
            shield_text = font.render("Bouclier", True, BLUE)
            screen.blit(shield_text, (10, 60))
        if active_jetpack_time > 0:
            jet_text = font.render("Jetpack", True, YELLOW)
            screen.blit(jet_text, (10, 90))

        if player_y > screen_height:
            if has_shield:
                has_shield = False
                player_y = screen_height // 2
                player_vy = jump_power
            else:
                running = False

        pygame.display.flip()

    if score > highscore:
        highscore = score
    return score, highscore


# PROGRAMME PRINCIPAL
show_start_screen()
highscore = 0
while True:
    score, highscore = game_loop(highscore)
    show_game_over_screen(score, highscore)
